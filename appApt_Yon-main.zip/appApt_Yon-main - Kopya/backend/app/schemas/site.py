"""
Site şemaları - beyaz liste doğrulama (gereksinim 1.2).
"""
import re

from pydantic import BaseModel, ConfigDict, field_validator

RE_SITE_ADI = re.compile(r"^[A-Za-zÇĞİÖŞÜçğıöşü0-9' .\-]{2,150}$")
RE_IL_ILCE = re.compile(r"^[A-Za-zÇĞİÖŞÜçğıöşü' \-]{2,30}$")
RE_ADRES = re.compile(r"^[A-Za-zÇĞİÖŞÜçğıöşü0-9' .,\-/()#]{5,255}$")
SITE_TIPLERI = {"APARTMAN", "SİTE", "REZİDANS", "PLAZA"}


def _site_adi_kontrol(v: str | None) -> str | None:
    if v is not None and not RE_SITE_ADI.fullmatch(v):
        raise ValueError("Site adı geçersiz karakter içeriyor.")
    return v


class SiteBase(BaseModel):
    site_adi: str
    site_tipi: str = "APARTMAN"
    adres: str | None = None
    il: str | None = None
    ilce: str | None = None
    aylik_aidat: float = 0
    aidat_gunu: int = 5

    _v_site_adi = field_validator("site_adi")(_site_adi_kontrol)

    @field_validator("site_tipi")
    @classmethod
    def tip_dogrula(cls, v: str) -> str:
        if v not in SITE_TIPLERI:
            raise ValueError(f"site_tipi şunlardan biri olmalı: {sorted(SITE_TIPLERI)}")
        return v

    @field_validator("il", "ilce")
    @classmethod
    def il_dogrula(cls, v: str | None) -> str | None:
        if v is not None and not RE_IL_ILCE.fullmatch(v):
            raise ValueError("İl/ilçe yalnızca harf içerebilir.")
        return v

    @field_validator("adres")
    @classmethod
    def adres_dogrula(cls, v: str | None) -> str | None:
        if v is not None and not RE_ADRES.fullmatch(v):
            raise ValueError("Adres geçersiz karakter içeriyor.")
        return v

    @field_validator("aylik_aidat")
    @classmethod
    def aidat_dogrula(cls, v: float) -> float:
        if v < 0 or v > 1_000_000:
            raise ValueError("Aylık aidat 0-1.000.000 aralığında olmalı.")
        return round(v, 2)

    @field_validator("aidat_gunu")
    @classmethod
    def gun_dogrula(cls, v: int) -> int:
        if not 1 <= v <= 28:
            raise ValueError("Aidat günü 1-28 arasında olmalı (Şubat uyumu).")
        return v


class SiteCreate(SiteBase):
    """Yeni site - firma_no token'dan gelir, istemciden ASLA alınmaz."""
    daire_sayisi: int = 0

    @field_validator("daire_sayisi")
    @classmethod
    def daire_dogrula(cls, v: int) -> int:
        if not 0 <= v <= 5000:
            raise ValueError("Daire sayısı 0-5000 arasında olmalı.")
        return v


class SiteUpdate(BaseModel):
    """Kısmi güncelleme - tüm alanlar opsiyonel, endpoint beyaz listesi uygular."""
    site_adi: str | None = None
    aylik_aidat: float | None = None
    aidat_gunu: int | None = None
    otomatik_borclandir: bool | None = None
    aktif_mi: bool | None = None

    _v_site_adi = field_validator("site_adi")(_site_adi_kontrol)

    @field_validator("aylik_aidat")
    @classmethod
    def aidat_dogrula(cls, v: float | None) -> float | None:
        if v is not None and (v < 0 or v > 1_000_000):
            raise ValueError("Aylık aidat 0-1.000.000 aralığında olmalı.")
        return v

    @field_validator("aidat_gunu")
    @classmethod
    def gun_dogrula(cls, v: int | None) -> int | None:
        if v is not None and not 1 <= v <= 28:
            raise ValueError("Aidat günü 1-28 arasında olmalı.")
        return v


class SiteResponse(SiteBase):
    model_config = ConfigDict(from_attributes=True)

    site_no: int
    firma_no: int
    daire_sayisi: int
    otomatik_borclandir: bool
    aktif_mi: bool