"""
SQLAlchemy 2.x declarative temel sınıfları.

- Base: tüm modellerin kökü
- TimestampMixin: created/updated alanlarını her tabloya tek satırla ekler
"""
from datetime import datetime

from sqlalchemy import DateTime, func
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    """Tüm modeller bu sınıftan türetilir."""
    pass


class TimestampMixin:
    """Otomatik zaman damgası. Kullanım: class Duyuru(Base, TimestampMixin)"""
    olusturma_tarihi: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), nullable=False)
    guncelleme_tarihi: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), onupdate=func.now(), nullable=False)