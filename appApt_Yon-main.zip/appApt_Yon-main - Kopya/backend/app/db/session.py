"""
Veritabanı oturum yönetimi - güvenlik ve dayanıklılık öncelikli.

- Tüm sorgular SQLAlchemy ORM ile parametrik çalışır (SQL injection koruması)
- Async engine: FastAPI uçları için (aiomysql)
- Sync engine:  Alembic migrasyonları ve Celery görevleri için (PyMySQL)
- pool_pre_ping: kopan bağlantıları kullanmadan önce tespit eder
- get_db bağımlılığı: her istekte YENİ oturum açar, hata durumunda
  otomatik rollback yapar (yarım kalan işlem veritabanını kirletmez)
"""
from collections.abc import AsyncGenerator, Generator

from sqlalchemy import create_engine
from sqlalchemy.ext.asyncio import (AsyncSession, async_sessionmaker,
                                    create_async_engine)
from sqlalchemy.orm import Session, sessionmaker

from app.core.config import settings

# ── Async engine (FastAPI) ────────────────────────────────────────────────────
async_engine = create_async_engine(
    settings.DATABASE_URL,
    pool_size=settings.DB_POOL_SIZE,
    max_overflow=settings.DB_MAX_OVERFLOW,
    pool_pre_ping=True,          # kopan bağlantıyı kullanmadan önce tespit et
    pool_recycle=1800,           # 30 dk'da eski bağlantıyı yenile (MySQL timeout)
    echo=settings.DEBUG,         # DEBUG'da SQL logu (üretimde kapalı)
)

AsyncSessionLocal = async_sessionmaker(
    bind=async_engine,
    class_=AsyncSession,
    expire_on_commit=False,      # commit sonrası lazy-load hatasını önler
    autoflush=False,
)

# ── Sync engine (Alembic migrasyonları + Celery görevleri) ───────────────────
sync_engine = create_engine(
    settings.DATABASE_URL_SYNC,
    pool_size=settings.DB_POOL_SIZE,
    max_overflow=settings.DB_MAX_OVERFLOW,
    pool_pre_ping=True,
    pool_recycle=1800,
    echo=False,
)

SyncSessionLocal = sessionmaker(
    bind=sync_engine,
    class_=Session,
    expire_on_commit=False,
    autoflush=False,
)


# ── Bağımlılıklar ──────────────────────────────────────────────────────────────
async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """
    FastAPI bağımlılığı - her istek için izole oturum.

    Kullanım:
        @router.get("/sites")
        async def liste(db: AsyncSession = Depends(get_db)): ...
    """
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()       # istek başarılıysa işlemleri onayla
        except Exception:
            await session.rollback()     # hata olursa geri al (kirletme)
            raise
        finally:
            await session.close()


def get_sync_db() -> Generator[Session, None, None]:
    """Celery görevleri ve script'ler için senkron oturum."""
    db = SyncSessionLocal()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()