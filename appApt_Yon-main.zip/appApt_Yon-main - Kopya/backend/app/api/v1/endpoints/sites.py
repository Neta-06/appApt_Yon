"""
Site uçları - tam CRUD, multi-tenant güvenlik modeli:

- site_no HER ZAMAN token'daki tenant ile doğrulanır (IDOR koruması)
- Yazma işlemleri: YÖNETİCİ / MUHASEBECİ (PoLP - gereksinim 2.3)
- firma_no istemciden ASLA alınmaz; token'daki kullanıcının firması kullanılır
- Liste: kullanıcının YETKİLİ olduğu siteler (cross-site yetki modeli)
"""
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import func, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.rbac import (Principal, get_current_principal, sadece_yonetici,
                           tenant_scope, yonetim_yetkili)
from app.db.session import get_db
from app.models.identity import KullaniciSite, Site
from app.schemas.site import SiteCreate, SiteResponse, SiteUpdate

router = APIRouter(prefix="/sites", tags=["sites"])


# ── Yardımcı: kullanıcının yetkili olduğu siteler ──────────────────────────────
async def _yetkili_site_nolar(db: AsyncSession, kullanici_no: int) -> list[int]:
    q = await db.execute(select(KullaniciSite.site_no).where(
        KullaniciSite.kullanici_no == kullanici_no,
        KullaniciSite.aktif_mi.is_(True)))
    return list(q.scalars().all())


async def _firma_no(db: AsyncSession, kullanici_no: int) -> int | None:
    """Yeni site açmak için kullanıcının firma_no'su."""
    from app.models.identity import Kullanici
    q = await db.execute(select(Kullanici.firma_no).where(
        Kullanici.kullanici_no == kullanici_no))
    return q.scalar()


# ── 1) Kullanıcının siteleri (login sonrası site seçim ekranı) ─────────────────
@router.get("/me", response_model=list[SiteResponse])
async def benim_sitelerim(
    db: AsyncSession = Depends(get_db),
    p: Principal = Depends(get_current_principal),
):
    """Kullanıcının yetkili olduğu TÜM siteler - cross-site yetki modeli."""
    site_nolar = await _yetkili_site_nolar(db, p.kullanici_no)
    if not site_nolar:
        return []
    q = await db.execute(select(Site).where(
        Site.site_no.in_(site_nolar), Site.aktif_mi.is_(True)))
    return [SiteResponse.model_validate(s) for s in q.scalars().all()]


# ── 2) Site detayı (tenant kapsamlı) ──────────────────────────────────────────
@router.get("/{site_no}", response_model=SiteResponse)
async def site_get(
    site_no: int,
    db: AsyncSession = Depends(get_db),
    p: Principal = Depends(get_current_principal),
):
    tenant_scope(site_no, p)  # IDOR: token'daki site ile eşleşmezse 403
    q = await db.execute(select(Site).where(Site.site_no == site_no))
    site = q.scalar_one_or_none()
    if site is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Site bulunamadı.")
    return SiteResponse.model_validate(site)


# ── 3) Yeni site oluştur (firma genelinde - sadece YÖNETİCİ) ──────────────────
@router.post("", response_model=SiteResponse, status_code=status.HTTP_201_CREATED)
async def site_olustur(
    body: SiteCreate,
    db: AsyncSession = Depends(get_db),
    p: Principal = Depends(sadece_yonetici),
):
    firma_no = await _firma_no(db, p.kullanici_no)
    if firma_no is None:
        raise HTTPException(status.HTTP_403_FORBIDDEN,
                            "Firma çalışanı değilsiniz, site oluşturamazsınız.")

    site = Site(
        firma_no=firma_no,          # token'dan gelir - istemci gönderemez
        site_adi=body.site_adi,
        site_tipi=body.site_tipi,
        adres=body.adres,
        il=body.il,
        ilce=body.ilce,
        daire_sayisi=body.daire_sayisi,
        aylik_aidat=body.aylik_aidat,
        aidat_gunu=body.aidat_gunu,
    )
    db.add(site)
    await db.flush()
    await db.refresh(site)

    # Oluşturan yönetici otomatik olarak siteye YÖNETİCİ yetkisiyle eklenir
    from datetime import date
    db.add(KullaniciSite(
        kullanici_no=p.kullanici_no, site_no=site.site_no,
        yetki="YÖNETİCİ", baslangic_tarihi=date.today()))
    return SiteResponse.model_validate(site)


# ── 4) Site güncelle (tenant kapsamlı, yönetim yetkisi) ────────────────────────
@router.patch("/{site_no}", response_model=SiteResponse)
async def site_guncelle(
    site_no: int,
    body: SiteUpdate,
    db: AsyncSession = Depends(get_db),
    p: Principal = Depends(yonetim_yetkili),
):
    tenant_scope(site_no, p)
    degerler = body.model_dump(exclude_unset=True)
    if not degerler:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Güncellenecek alan yok.")

    # Beyaz liste: yalnızca güncellenebilir alanlara izin ver
    izinli = {"site_adi", "aylik_aidat", "aidat_gunu",
              "otomatik_borclandir", "aktif_mi"}
    degerler = {k: v for k, v in degerler.items() if k in izinli}

    q = await db.execute(update(Site).where(Site.site_no == site_no)
                         .values(**degerler))
    if q.rowcount == 0:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Site bulunamadı.")

    q = await db.execute(select(Site).where(Site.site_no == site_no))
    return SiteResponse.model_validate(q.scalar_one())


# ── 5) Site pasifleştir (soft delete - veri kaybı yok) ─────────────────────────
@router.delete("/{site_no}", status_code=status.HTTP_204_NO_CONTENT)
async def site_pasiflestir(
    site_no: int,
    db: AsyncSession = Depends(get_db),
    p: Principal = Depends(sadece_yonetici),
):
    tenant_scope(site_no, p)
    q = await db.execute(
        update(Site).where(Site.site_no == site_no).values(aktif_mi=False))
    if q.rowcount == 0:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Site bulunamadı.")


# ── 6) Firma geneli özet (cross-site rapor - muhasebeci/yönetici) ─────────────
@router.get("/ozet/firma")
async def firma_ozeti(
    db: AsyncSession = Depends(get_db),
    p: Principal = Depends(yonetim_yetkili),
):
    """Kullanıcının yetkili olduğu tüm sitelerin daire/aktiflik özeti."""
    site_nolar = await _yetkili_site_nolar(db, p.kullanici_no)
    if not site_nolar:
        return {"toplam_site": 0, "toplam_daire": 0, "siteler": []}

    q = await db.execute(
        select(Site.site_no, Site.site_adi, Site.site_tipi,
               Site.daire_sayisi, Site.aktif_mi, Site.aylik_aidat)
        .where(Site.site_no.in_(site_nolar)))
    siteler = [dict(r._mapping) for r in q.all()]
    return {
        "toplam_site": len(siteler),
        "aktif_site": sum(1 for s in siteler if s["aktif_mi"]),
        "toplam_daire": sum(s["daire_sayisi"] for s in siteler),
        "siteler": siteler,
    }