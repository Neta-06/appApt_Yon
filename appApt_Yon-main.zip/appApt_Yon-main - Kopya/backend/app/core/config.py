"""
Merkezi yapılandırma - TÜM gizli değerler ortam değişkeninden gelir (.env repo'ya girmez).

Bölümler:
  1) Uygulama        2) Veritabanı     3) Redis
  4) JWT/Oturum      5) Şifre politikası  6) MFA
  7) Şifreleme       8) CORS/Çerez     9) Güvenlik başlıkları
 10) SMS/E-posta    11) Celery        12) Loglama/SIEM
 13) Banka entegrasyonu              14) Dosya/Belge
"""
from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # ── 1) Uygulama ──────────────────────────────────────────────────────────
    APP_NAME: str = "Yönetimcell API"
    ENV: str = "production"                    # development | staging | production
    DEBUG: bool = False                        # ASLA True olmamalı (stack trace sızdırır)
    API_V1_PREFIX: str = "/api/v1"
    TIMEZONE: str = "Europe/Istanbul"

    # ── 2) Veritabanı (MySQL 8.x) ────────────────────────────────────────────
    DB_HOST: str = "localhost"
    DB_PORT: int = 3306
    DB_USER: str = "app_user"
    DB_PASSWORD: str = "CHANGE_ME"
    DB_NAME: str = "appApartman"
    DB_POOL_SIZE: int = 10
    DB_MAX_OVERFLOW: int = 20

    @property
    def DATABASE_URL(self) -> str:
        return (f"mysql+aiomysql://{self.DB_USER}:{self.DB_PASSWORD}"
                f"@{self.DB_HOST}:{self.DB_PORT}/{self.DB_NAME}")

    @property
    def DATABASE_URL_SYNC(self) -> str:
        return (f"mysql+pymysql://{self.DB_USER}:{self.DB_PASSWORD}"
                f"@{self.DB_HOST}:{self.DB_PORT}/{self.DB_NAME}")

    # ── 3) Redis ─────────────────────────────────────────────────────────────
    REDIS_HOST: str = "localhost"
    REDIS_PORT: int = 6379
    REDIS_PASSWORD: str = "CHANGE_ME"
    REDIS_DB: int = 0

    @property
    def REDIS_URL(self) -> str:
        return (f"redis://:{self.REDIS_PASSWORD}@{self.REDIS_HOST}:"
                f"{self.REDIS_PORT}/{self.REDIS_DB}")

    # ── 4) JWT / Oturum (gereksinim 2.4: kısa ömürlü) ────────────────────────
    JWT_SECRET_KEY: str = "CHANGE_ME_64_BYTE_HEX"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 15
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    MFA_TOKEN_EXPIRE_MINUTES: int = 5
    # Şüpheli yeniden-kullanım tespitinde oturum ailesi blok süresi (saniye)
    SESSION_FAMILY_BLOCK_SECONDS: int = 900

    # ── 5) Şifre politikası (gereksinim 2.2) ────────────────────────────────
    PASSWORD_MIN_LENGTH: int = 12
    PASSWORD_REQUIRE_UPPER: bool = True
    PASSWORD_REQUIRE_LOWER: bool = True
    PASSWORD_REQUIRE_DIGIT: bool = True
    PASSWORD_REQUIRE_SPECIAL: bool = True
    # Parola geçmişi: son N parolayı tekrar kullanamaz
    PASSWORD_HISTORY_COUNT: int = 5

    # ── 6) MFA ───────────────────────────────────────────────────────────────
    MFA_ISSUER: str = "Yonetimcell"
    MFA_CODE_LENGTH: int = 6
    MFA_VALID_WINDOW: int = 1                  # saat kayması toleransı (30sn adım)
    MFA_MAX_DENEME: int = 5                    # sonra geçici kilit

    # ── 7) Uygulama içi şifreleme (gereksinim 3.2: AES-256) ─────────────────
    # python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
    FIELD_ENCRYPTION_KEY: str = "CHANGE_ME_FERNET_KEY"

    # ── 8) CORS / Çerez ─────────────────────────────────────────────────────
    # Virgülle ayrık TAM origin listesi - wildcard ASLA kullanılmaz
    ALLOWED_ORIGINS: str = "https://app.yonetimcell.com.tr"
    COOKIE_SECURE: bool = True
    COOKIE_SAMESITE: str = "strict"

    # ── 9) Güvenlik başlıkları ───────────────────────────────────────────────
    HSTS_MAX_AGE: int = 31536000
    HSTS_INCLUDE_SUBDOMAINS: bool = True

    # ── 10) SMS / E-posta bildirim modülü ───────────────────────────────────
    SMS_PROVIDER: str = "netgsm"               # netgsm | twilio | vitrini
    SMS_API_USER: str = ""
    SMS_API_PASSWORD: str = ""
    SMS_API_URL: str = "https://api.netgsm.com.tr/sms/send/otp"
    SMS_FROM: str = "YONETMCELL"
    MAIL_SERVER: str = "smtp.yonetimcell.com.tr"
    MAIL_PORT: int = 587
    MAIL_USERNAME: str = ""
    MAIL_PASSWORD: str = ""
    MAIL_USE_TLS: bool = True
    MAIL_FROM: str = "noreply@yonetimcell.com.tr"

    # ── 11) Celery ───────────────────────────────────────────────────────────
    # otomatik borçlandırma (aidat_gunu), hatırlatmalar, bildirim kuyruğu
    CELERY_BROKER_URL: str = ""                # boşsa REDIS_URL kullanılır
    CELERY_RESULT_BACKEND: str = ""
    AIDAT_HATIRLATMA_GUNU: int = 3             # son ödeme gününden kaç gün önce

    @property
    def broker_url(self) -> str:
        return self.CELERY_BROKER_URL or self.REDIS_URL

    @property
    def result_backend(self) -> str:
        return self.CELERY_RESULT_BACKEND or self.REDIS_URL

    # ── 12) Loglama / SIEM (gereksinim 5.2) ─────────────────────────────────
    LOG_LEVEL: str = "INFO"                    # DEBUG yalnızca geliştirmede
    LOG_JSON: bool = True                      # SIEM'e JSON log
    LOG_SENSITIVE_MASK: bool = True            # TC/telefon maskeli loglanır
    SIEM_WEBHOOK_URL: str = ""                 # anomali webhook (opsiyonel)

    # ── 13) Banka entegrasyonu ───────────────────────────────────────────────
    BANKA_OPENAPI_CLIENT_ID: str = ""
    BANKA_OPENAPI_CLIENT_SECRET: str = ""
    BANKA_OPENAPI_BASE_URL: str = ""

    # ── 14) Dosya / Belge modülü ─────────────────────────────────────────────
    UPLOAD_DIR: str = "/srv/uploads"
    MAX_UPLOAD_MB: int = 10
    # İzin verilen dosya türleri (beyaz liste)
    ALLOWED_UPLOAD_TYPES: str = "pdf,jpg,jpeg,png,xlsx,docx"


@lru_cache
def get_settings() -> Settings:
    """Singleton - her import'ta tek örnek. Testlerde cache'i temizle: get_settings.cache_clear()"""
    return Settings()


settings = get_settings()